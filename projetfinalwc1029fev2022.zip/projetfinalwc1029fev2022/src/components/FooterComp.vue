<template>
    <div id="FooterComp">
        <h2> {{info1}}</h2>
    </div>
</template>

<script>
export default {
    name: "FooterComp", 
        data (){
        return {
            info1: " Copyrigth @ Fevrier 2022",
        };
    },
};

</script>